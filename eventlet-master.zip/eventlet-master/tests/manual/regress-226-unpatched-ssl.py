import eventlet
import requests
requests.get('https://www.google.com/').status_code
